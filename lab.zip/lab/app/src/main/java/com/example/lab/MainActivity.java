package com.example.lab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class MainActivity extends AppCompatActivity {
    Button rss_button;
    Button notification_button;
    Button sqldatabase_button,email_button;
    Button calculator_button;
    Button graphics_button,threading_button,gps_button,sd_btn;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        rss_button=findViewById(R.id.rss);
        notification_button=findViewById(R.id.notification_button);
        sqldatabase_button=findViewById(R.id.sqldatabase_button);
        rss_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent rss_intent = new Intent(MainActivity.this,rss.class);
                startActivity(rss_intent);
            }
        });
        notification_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent noti_intent=new Intent(MainActivity.this,notification.class);
                startActivity(noti_intent);
            }
        });
        sqldatabase_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sql_intent=new Intent(MainActivity.this,SQLDatabase.class);
                startActivity(sql_intent);
            }
        });
        email_button=findViewById(R.id.btn_email);
        email_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent email_intent=new Intent(MainActivity.this,Email.class);
                startActivity(email_intent);
            }
        });
        calculator_button=findViewById(R.id.calculator_button);
        calculator_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    Intent cal_intent=new Intent(MainActivity.this,Calculator.class);
                    startActivity(cal_intent);
            }
        });
        graphics_button=findViewById(R.id.graphics_btn);
        graphics_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gra_intent=new Intent(MainActivity.this,Graphics.class);
                startActivity(gra_intent);
            }
        });
        threading_button=findViewById(R.id.threading_btn);
        threading_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent thread_intent=new Intent(MainActivity.this,Theading.class);
                startActivity(thread_intent);
            }
        });
        gps_button=findViewById(R.id.gps);
        gps_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent gps_intent=new Intent(MainActivity.this,GPS.class);
                startActivity(gps_intent);
            }
        });
        sd_btn=findViewById(R.id.sd_btn);
        sd_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent sd_intent=new Intent(MainActivity.this,sd.class);
                startActivity(sd_intent);
            }
        });



    }


}

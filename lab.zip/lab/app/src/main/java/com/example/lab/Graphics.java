package com.example.lab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Graphics extends AppCompatActivity {
    EditText length,breadth;
    Button click;
    CustomView customView;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_graphics);
        length=findViewById(R.id.length);
        breadth=findViewById(R.id.breadth);
        click=findViewById(R.id.click);
        customView=findViewById(R.id.customView);
        click.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                    customView.setValues(Integer.valueOf(String.valueOf(length.getText())),Integer.valueOf(String.valueOf(breadth.getText())));

            }
        });
    }
}

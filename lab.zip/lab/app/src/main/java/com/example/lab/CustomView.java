package com.example.lab;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Rect;
import android.os.Build;
import android.util.AttributeSet;
import android.view.View;

import androidx.annotation.Nullable;
import androidx.annotation.RequiresApi;
import androidx.constraintlayout.solver.widgets.Rectangle;

public class CustomView extends View {
    private Rect rect;
    private Paint paint,paintcircle;
    private int Length=100;
    private int Breadth=300;
    public CustomView(Context context) {
        super(context);
        init(null);
    }

    public CustomView(Context context, AttributeSet attrs) {
        super(context, attrs);
        init(attrs);
    }

    public CustomView(Context context, AttributeSet attrs, int defStyleAttr) {
        super(context, attrs, defStyleAttr);
        init(attrs);
    }

    @RequiresApi(api = Build.VERSION_CODES.LOLLIPOP)
    public CustomView(Context context, AttributeSet attrs, int defStyleAttr, int defStyleRes) {
        super(context, attrs, defStyleAttr, defStyleRes);
        init(attrs);
    }
    private void init(@Nullable AttributeSet set){
        rect=new Rect();
        paint= new Paint();
        paintcircle= new Paint();

    }
    protected void onDraw(Canvas canvas){
        //canvas.drawColor(Color.RED);
        rect.left=50;
        rect.top=50;
        rect.right=rect.left+Length;
        rect.bottom=rect.top+Breadth;
        paint.setColor(Color.GREEN);
        canvas.drawRect(rect,paint);
        paintcircle.setColor((Color.BLUE));
        float cx=300,cy=300;
        canvas.drawCircle(cx,cy,Length,paintcircle);

    }
    protected void setValues(int length,int breadth){
        Length=length;
        Breadth=breadth;

    }
}


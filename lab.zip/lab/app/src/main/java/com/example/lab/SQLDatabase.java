package com.example.lab;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import android.database.Cursor;
import android.os.Bundle;
import android.os.Message;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class SQLDatabase extends AppCompatActivity {

    DatabaseHelper myDb;
    EditText text_name,text_surname,text_marks,text_ID;
    Button btn_insert,btn_Dataview,btn_updatedata,btn_Delete;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sqldatabase);

        myDb=new DatabaseHelper(this);
        myDb.getWritableDatabase();

        text_marks=findViewById(R.id.editTextMarks);
        text_surname=findViewById(R.id.editTextSurname);
        text_name=findViewById(R.id.editTextName);
        text_ID=findViewById(R.id.editTextId);

        btn_insert=findViewById(R.id.btn_insert);
        btn_insert.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isinserted=myDb.insertData(text_name.getText().toString(),text_surname.getText().toString(),text_marks.getText().toString());
                if(isinserted==true){
                    Toast.makeText(SQLDatabase.this,"data inserted",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(SQLDatabase.this,"data not inserted",Toast.LENGTH_SHORT).show();
                }
            }
        });
        btn_Dataview=findViewById(R.id.btn_ViewAll);
        btn_Dataview.setOnClickListener((new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Cursor cur=myDb.getAllData();
                if(cur.getCount()==0){
                    Toast.makeText(SQLDatabase.this,"Empty",Toast.LENGTH_SHORT).show();
                    return;
                }
                StringBuffer buffer=new StringBuffer();
                while(cur.moveToNext()){
                    buffer.append("ID:"+cur.getString(0)+"\n");
                    buffer.append("Name:"+cur.getString(1)+"\n");
                    buffer.append("Surname:"+cur.getString(2)+"\n");
                    buffer.append("Marks:"+cur.getString(3)+"\n");
                }
                showMessage("Data",buffer.toString());
            }

            public void showMessage(String data, String Message){
                AlertDialog.Builder builder=new AlertDialog.Builder(SQLDatabase.this);
                builder.setCancelable(true);
                builder.setTitle(data);
                builder.setMessage(Message);
                builder.show();

            }
        }));
        btn_updatedata=findViewById(R.id.btn_update);
        btn_updatedata.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                boolean isupdate=myDb.updateData(text_ID.getText().toString(),text_name.getText().toString(),text_surname.getText().toString(),text_marks.getText().toString());
                if(isupdate==true){
                    Toast.makeText(SQLDatabase.this,"data updated",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(SQLDatabase.this,"data not updated",Toast.LENGTH_SHORT).show();
                }
            }
        });
        btn_Delete=findViewById(R.id.btn_delete);
        btn_Delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Integer isupdate=myDb.deleteData(text_ID.getText().toString());
                if(isupdate>0){
                    Toast.makeText(SQLDatabase.this,"data deleted",Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(SQLDatabase.this,"data not deleted",Toast.LENGTH_SHORT).show();
                }
            }
        });
        }

}



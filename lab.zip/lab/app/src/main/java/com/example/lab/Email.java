package com.example.lab;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class Email extends AppCompatActivity {

    Button email_btn;
    EditText editto,editmessage,editsubject;
    private static final String TAG ="Email" ;
    String to,message,subject;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_email);
        editsubject=findViewById(R.id.editsubject);
        editto=findViewById(R.id.editto);
        editmessage=findViewById(R.id.editMessage);
        email_btn=findViewById(R.id.email_btn);
        email_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                GetData();
            }
            private void GetData(){
                Log.d(TAG,"sendmail: ");
                //String[] to={"dragonsrinu@gmail.com","sowmyak17108@gmail.com"};
                String[] to={editto.getText().toString()};
                subject=editsubject.getText().toString();
                message=editmessage.getText().toString();
                Intent intent=new Intent(Intent.ACTION_SENDTO);
                intent.setData(Uri.parse("mailto:"));
                intent.putExtra(Intent.EXTRA_EMAIL,to);
                intent.putExtra(Intent.EXTRA_SUBJECT,subject);
                intent.putExtra(Intent.EXTRA_TEXT,message);

                //intent.setType("message/rfc822");
                startActivity(Intent.createChooser(intent,"Select Email Sending Apps"));


            }
        });
    }

}

package com.example.lab;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.os.Handler;
import android.util.Log;
import android.view.View;
import android.widget.Button;

public class Theading extends AppCompatActivity {
    private static final String TAG = "Theading";
    private Handler mainHandler=new Handler();
    private volatile boolean stopThread=false;
    Button thread_btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_theading);
        thread_btn=findViewById(R.id.start_btn2);
    }
    public void startThread(View view){
//        ExampleThread thread=new ExampleThread(10);
//        thread.start();
        stopThread=false;
        ExampleRunnable runnable=new ExampleRunnable(10);
        new Thread(runnable).start();

    }
    public void stopThread(View view){
            stopThread=true;
    }
    class ExampleThread extends Thread{
        int seconds;
        ExampleThread(int seconds){
            this.seconds=seconds;
        }
        @Override
        public void run() {
            for(int i=0;i<seconds;i++){
                Log.d(TAG, "startThread: "+i);
                try{
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
    class ExampleRunnable implements  Runnable{
        int seconds;
        ExampleRunnable(int seconds){
            this.seconds=seconds;
        }
        @Override
        public void run() {
            for(int i=0;i<seconds;i++){
                if(stopThread)
                    return;
                if(i==5){
                   /* mainHandler.post(new Runnable() { //first method
                        @Override
                        public void run() {
                            thread_btn.setText("50%");
                        }
                    });
                    thread_btn.post(new Runnable() {//second method
                        @Override
                        public void run() {
                            thread_btn.setText("50%");
                        }
                    });*/
                    runOnUiThread(new Runnable() {//third method
                        @Override
                        public void run() {
                            thread_btn.setText("50%");
                        }
                    });
                }
                Log.d(TAG, "startThread: "+i);
                try{
                    Thread.sleep(1000);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            }
        }
    }
}
